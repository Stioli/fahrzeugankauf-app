# Kaufvertrag — Juristische Pflichtbestandteile

Der Kaufvertrag (Privat → Gewerbe) muss diese 11 Paragraphen enthalten:

1. **§ 1 Vertragsgegenstand** – genaue Fahrzeugbeschreibung mit FIN, Kennzeichen, EZ, KM, Halterzahl
2. **§ 2 Kaufpreis + Zahlung + GwG-Hinweis** – Betrag in Ziffern und Worten, Zahlungsweise, GwG ab 10.000 €
3. **§ 3 Übergabe + Gefahrübergang** (§ 446 BGB)
4. **§ 4 Abmeldung** – wer, wann
5. **§ 5 Gewährleistungsausschluss** mit § 444 BGB-Grenzen (gilt nicht bei arglistig verschwiegenen Mängeln)
6. **§ 6 Nachträglich festgestellte Mängel** – Abzug vom Kaufpreis
7. **§ 7 Zubehör/Extras-Nachberechnung** – z.B. Winterräder zum Neupreis
8. **§ 8 Datenschutz** (DSGVO Art. 6)
9. **§ 9 Schriftformklausel**
10. **§ 10 Salvatorische Klausel**
11. **§ 11 Gerichtsstand Stuttgart**

## Zusicherungen-Box

Separat hervorgehoben werden die Zusicherungen des Verkäufers:
- Unfallfrei (ja/nein, ggf. Schadenshöhe)
- Hagelschaden (ja/nein)
- Nachlackiert (ja/nein)
- Ex-Mietwagen (ja/nein)
- EU-Fahrzeug (ja/nein)

Diese sind rechtlich relevante Zusicherungen, deren bewusst falsche Angabe den Gewährleistungsausschluss aufhebt (§ 444 BGB).

## Bekannte Mängel

Auf dem Kaufvertrag werden alle dem Verkäufer bekannten Mängel aufgelistet. Diese sind explizit ausgeschlossen vom Abzug bei späterer Feststellung — sie wurden ja schon kalkuliert.

## Unterschriftenfelder

- Verkäufer: vollständiger Name + Datum + Ort
- Käufer: Vertretungsberechtigt für Autohaus Stieber GmbH + Datum + Ort
