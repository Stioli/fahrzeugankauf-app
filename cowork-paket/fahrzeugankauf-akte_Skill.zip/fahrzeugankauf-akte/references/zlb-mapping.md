# Fahrzeugschein (ZLB Teil I) auslesen

Die Zulassungsbescheinigung Teil I hat genormte EU-Feldcodes. So liest du sie systematisch aus:

| Code | Inhalt | Im Akten-Schema |
|------|--------|-----------------|
| A | Amtliches Kennzeichen | `fahrzeug.kennzeichen` |
| B | Datum der Erstzulassung | `fahrzeug.erstzulassung` (Format: DD.MM.YYYY) |
| C.1.1 | Name / Firmenname | `verkaeufer.name` (Nachname) |
| C.1.2 | Vorname(n) | `verkaeufer.name` (Vorname) |
| C.1.3 | Anschrift | `verkaeufer.strasse` + `verkaeufer.plz_ort` |
| D.1 | Marke / Hersteller | `fahrzeug.hersteller` |
| D.3 | Handelsbezeichnung | `fahrzeug.modell` |
| E | FIN/VIN (17 Zeichen) | `fahrzeug.fin` |
| J | Fahrzeugklasse | `fahrzeug.aufbau` (Hinweis: M1 = PKW) |
| P.1 | Hubraum cm³ | `fahrzeug.hubraum_ccm` |
| P.2 | Nennleistung kW | `fahrzeug.leistung_kw` (PS = kW × 1.36) |
| P.3 | Kraftstoffart | `fahrzeug.kraftstoff` |
| R | Farbe | `fahrzeug.farbe` |
| 14 | Emissionsklasse | `fahrzeug.schadstoffklasse` |

## HU-Datum

Steht oft auf der Vorderseite als "X Nächste HU MM.YYYY". **Bevorzugt aus Direktannahmebericht** übernehmen, da meist aktueller.

## Kraftstoff-Mapping

ZLB-Werte → Akten-Werte:

| ZLB-Wert | Akten-Wert |
|----------|------------|
| BENZIN | Benzin |
| DIESEL | Diesel |
| ELEKTRO | Elektro |
| HYBR.BENZIN/E | Hybrid |
| HYBR.DIESEL/E | Hybrid |
| PLUG-IN | Plug-in-Hybrid |

## PS-Berechnung

```python
ps = round(int(kw) * 1.359621617)   # offizieller Faktor
```

## Halteranzahl

Steht NICHT in der ZLB Teil I. Muss bei Oli oder Verkaufsberater erfragt werden — typisch aus dem Kaufvertrag-Foto (Feld "Fzg Halter Gesamt").

## Beispiel: Hyundai Tucson Csontos

ZLB:
- A: EM NA2004
- B: 30.04.2021
- C.1.1: Csontos
- C.1.2: Aleksander
- C.1.3: Hauptstraße 57, 79341 Kenzingen
- D.1: HYUNDAI
- D.3: TUCSON, IX35
- E: TMAJE81BGMJ011029
- P.1: 01598
- P.2: 0148 (= 148 kW = 201 PS)
- P.3: Hybr.Benzin/E

→ Akte:
```python
{
    "verkaeufer": {
        "name": "Aleksander Csontos",
        "strasse": "Hauptstraße 57",
        "plz_ort": "79341 Kenzingen",
    },
    "fahrzeug": {
        "hersteller": "Hyundai",
        "modell": "Tucson",
        "kennzeichen": "EM NA2004",
        "erstzulassung": "30.04.2021",
        "fin": "TMAJE81BGMJ011029",
        "hubraum_ccm": "1.598",
        "leistung_kw": "148",
        "leistung_ps": "201",
        "kraftstoff": "Hybrid",
    }
}
```
