# Mängel-Mapping aus Direktannahmebericht

Wertet einen Direktannahmebericht systematisch aus und erzeugt verkaufsfähige Mängeltexte.

## Grundprinzip

Jede Zeile mit Status **`n.i.O`** wird zu einem Mängeleintrag. Die Beschreibung wird in eine professionelle Formulierung umgewandelt.

## Standard-Mappings

| Direktannahme-Zeile | → Baugruppe | → Beschreibung |
|---------------------|-------------|----------------|
| HU-Datum / HU fällig | HU/TÜV | "HU und Inspektion <MM/YYYY> fällig" |
| Lackierung/Karosserie - Türkanten abgeschlagen | Karosserie / Lack | "Türkanten abgeschlagen" |
| Lackierung/Karosserie - 1 Dellen VL | Karosserie / Lack | "Delle VL Türeinstieg – ausbessern" |
| Lackierung/Karosserie - mehrere Lackschäden | Karosserie / Lack | "Mehrere Lackschäden" |
| Polsterung - Fahrersitzpolster abgenutzt | Innenraum | "Fahrersitzpolster abgenutzt – Aufpolsterung erforderlich" |
| Polsterung - Hundehalter | Innenraum | "Innenraum – Tierhaare, Intensivreinigung erforderlich" |
| Innenraum Sichtprüfung n.i.O | Innenraum | "Innenraum Sichtprüfung – Detail nach Vorgabe" |
| Bremsen Sichtprüfung VA | Bremsanlage | "Bremsbeläge/Scheiben VA an Abfahrgrenze" |
| Bremsen Sichtprüfung HA | Bremsanlage | "Bremsbeläge/Scheiben HA an Abfahrgrenze" |
| Auspuff n.i.O | Abgasanlage | "Auspuff – Undichtigkeit/Korrosion" |
| Reifen Profiltiefe (v.l.) | Reifen | "Reifen vorne links unter Mindestprofil – Erneuerung" |
| Reifen Profiltiefe (v.r.) | Reifen | "Reifen vorne rechts unter Mindestprofil – Erneuerung" |
| Reifen Profiltiefe (h.l.) | Reifen | "Reifen hinten links unter Mindestprofil – Erneuerung" |
| Reifen Profiltiefe (h.r.) | Reifen | "Reifen hinten rechts unter Mindestprofil – Erneuerung" |
| Felgen (v.l.) n.i.O | Fahrwerk | "Felge vorne links beschädigt – Austausch erforderlich" |
| Felgen (v.r.) n.i.O | Fahrwerk | "Felge vorne rechts beschädigt – Austausch erforderlich" |
| Felgen (h.l.) n.i.O | Fahrwerk | "Felge hinten links beschädigt – Austausch erforderlich" |
| Felgen (h.r.) n.i.O | Fahrwerk | "Felge hinten rechts beschädigt – Austausch erforderlich" |
| Undichtigkeiten - Motorölverlust Ventildeckel | Motor | "Motorölverlust Ventildeckel – Dichtung wechseln" |
| Undichtigkeiten - Kühlmittel | Motor | "Kühlmittelverlust – Dichtung/Schlauch prüfen" |
| Flüssigkeitsstände n.i.O | Motor | "Flüssigkeiten – Nachfüllen/Erneuerung" |
| Wischblätter vorne | Verschleißteile | "Wischblätter vorne erneuern" |
| Wischblätter hinten | Verschleißteile | "Wischblatt hinten erneuern" |
| Verglasung n.i.O | Verglasung | "Steinschlag/Riss in Windschutzscheibe" |
| Beleuchtung-Funktion n.i.O | Elektrik | "Beleuchtung – Lampe defekt" |
| Pannenset/Reserverad fehlend | Ausstattung | "Pannenset/Reserverad ergänzen" |
| Verbandskasten n.i.O | Ausstattung | "Verbandskasten erneuern (abgelaufen)" |

## Pflicht-Endposition

**IMMER** als letzte Position ergänzen:

```python
{
    "pos": <next>,
    "baugruppe": "Aufbereitung",
    "beschreibung": "Fahrzeugaufbereitung innen/außen für Wiederverkauf"
}
```

## Optional

Falls auf Kaufvertrag-Foto handschriftliche Mängel ergänzt sind (z.B. "Kratzer Beifahrerseite"), ebenfalls aufnehmen.

## Erweiterung durch Meister

Der Meister kann in Stufe 2 zusätzliche Mängel ergänzen, die im Direktannahmebericht nicht stehen (z.B. Probefahrt-Erkenntnisse). Diese werden manuell zur Liste hinzugefügt.

## Sortierung

Mängel werden in der Liste in dieser Reihenfolge geführt:
1. HU/TÜV (immer ganz oben, wenn vorhanden)
2. Sicherheitsrelevant: Bremsanlage, Reifen, Fahrwerk
3. Motor / Antrieb
4. Karosserie / Lack
5. Innenraum
6. Verschleißteile / Elektrik / Verglasung
7. Aufbereitung (immer ganz unten)

## Beispiel: Aleksander Csontos Tucson

Aus Direktannahme `EM NA2004`:
- HU-Datum - HU und Insp. 05/26 fällig **n.i.O**
- Lackierung/Karosserie - Türkanten abgeschlagen **n.i.O**
- Polsterung - Fahrersitzpolster abgenutzt **n.i.O**
- Undichtigkeiten - Motorölverlust Ventildeckel **n.i.O**
- Felgen (v.r.) **n.i.O**

→ Mängelliste (sortiert):
```python
[
    {"pos": 1, "baugruppe": "HU/TÜV", "beschreibung": "HU und Inspektion 05/2026 fällig"},
    {"pos": 2, "baugruppe": "Fahrwerk", "beschreibung": "Felge vorne rechts beschädigt – Austausch erforderlich"},
    {"pos": 3, "baugruppe": "Motor", "beschreibung": "Motorölverlust Ventildeckel – Dichtung wechseln"},
    {"pos": 4, "baugruppe": "Karosserie / Lack", "beschreibung": "Türkanten abgeschlagen"},
    {"pos": 5, "baugruppe": "Innenraum", "beschreibung": "Fahrersitzpolster abgenutzt – Aufpolsterung erforderlich"},
    {"pos": 6, "baugruppe": "Aufbereitung", "beschreibung": "Fahrzeugaufbereitung innen/außen für Wiederverkauf"},
]
```
