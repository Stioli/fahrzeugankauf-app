# Extras-Checkliste — Standard für Stieber-Ankaufprozess

Diese Liste wird in **Stufe 1 (Datenaufnahme)** mit dem Kunden durchgegangen. Frage strukturiert und Block-weise (nicht alle auf einmal). Trage jedes Extra entweder als `True`, `False` oder mit Detail (z.B. Klimaautomatik mit Zonen-Anzahl) ein.

## Block 1: Sitze & Komfort (8 Punkte)

| Feld | Werte | Hinweis |
|------|-------|---------|
| `panoramadach` | True/False | inkl. Schiebedach-Variante |
| `schiebedach` | True/False | nur wenn KEIN Panorama |
| `lederausstattung` | "Voll" / "Teil" / "Stoff" | "Stoff" = Standard, dann False |
| `sitzheizung_vorne` | True/False | meist Standard ab Mittelklasse |
| `sitzheizung_hinten` | True/False | seltener |
| `sitzbelueftung` | True/False | Premium-Feature |
| `elektrische_sitze` | "Beide" / "Fahrer" / "Nein" | mit/ohne Memory siehe nächste Zeile |
| `sitz_memory` | True/False | nur prüfen wenn elektr. Sitze ja |

## Block 2: Klima & Heizung (3 Punkte)

| Feld | Werte | Hinweis |
|------|-------|---------|
| `klimaautomatik` | "1" / "2" / "3" / "4" / "Manuell" | Anzahl Zonen oder "Manuell" für Klimaanlage |
| `lenkradheizung` | True/False | |
| `standheizung` | "Werks" / "Nachgerüstet" / "Nein" | wenn ja, ob Werks oder nachgerüstet |

## Block 3: Multimedia & Navigation (5 Punkte)

| Feld | Werte | Hinweis |
|------|-------|---------|
| `navigation` | "Werks" / "Smartphone" / "Nein" | Werks-Navi vs. nur CarPlay/AA |
| `apple_carplay_android_auto` | True/False | meist beides oder nichts |
| `dab_radio` | True/False | DAB+ |
| `bluetooth` | True/False | meist Standard |
| `soundsystem` | "Premium-Marke" / "Standard" / "" | z.B. "Bose", "B&O", "Harman/Kardon", "Burmester" |

## Block 4: Licht & Sicht (4 Punkte)

| Feld | Werte | Hinweis |
|------|-------|---------|
| `licht_typ` | "LED" / "Matrix-LED" / "Laser" / "Xenon" / "Halogen" | wichtigster Faktor für Wertbestimmung |
| `head_up_display` | True/False | |
| `rueckfahrkamera` | True/False | |
| `kamera_360` | True/False | nur prüfen wenn Rückfahrkamera ja |

## Block 5: Park- & Fahrassistenz (5 Punkte)

| Feld | Werte | Hinweis |
|------|-------|---------|
| `eph_vorne` | True/False | EPH = Einparkhilfe (akustisch/optisch) |
| `eph_hinten` | True/False | meist Standard |
| `park_assistent` | True/False | aktiver Parkassistent (lenkt selbst) |
| `adaptive_cruise` | True/False | abstandsgeregelter Tempomat |
| `spurhalteassistent` | True/False | meist mit Verkehrszeichenerkennung gekoppelt |

## Block 6: Komfort-Zugang & Anhängelast (3 Punkte)

| Feld | Werte | Hinweis |
|------|-------|---------|
| `keyless_go` | True/False | Schlüssellos öffnen + starten |
| `elektr_heckklappe` | "Mit Sensor" / "Ja" / "Nein" | mit Fußsensor = Premium |
| `ahk` | "Fest" / "Abnehmbar" / "Elektrisch" / "Nein" | wichtig für Wertbestimmung |

## Block 7: Reifen / Räder / Sonstiges (4 Punkte)

| Feld | Werte | Hinweis |
|------|-------|---------|
| `alufelgen_sommer` | True/False + Zoll-Größe | z.B. "True (19 Zoll)" |
| `winterreifen_vorhanden` | True/False | werden mit übergeben? |
| `winterreifen_art` | "Alu" / "Stahl" / "" | nur wenn vorhanden |
| `werksgarantie_aktiv` | True/False + bis Datum | wenn ja, Datum erfragen |

## Block 8: Freitext (immer am Ende abfragen)

> "Hat der Wagen noch besondere Sonderausstattung, die nicht in der Liste stand?"

Frei eintragen in `extras_freitext` als Mehrzeilenstring.

## Ablauf in der Tablet-Nutzung

Idealer Dialog für Verkaufsberater:

```
Verkaufsberater fragt Kunde: "Können wir die Ausstattung kurz durchgehen? Ich frage 
gruppenweise – sag einfach immer ja/nein."

Block 1 - Sitze: Panoramadach? Lederausstattung? Sitzheizung? ...
[Bestätigung]

Block 2 - Klima: Klimaautomatik mit wie vielen Zonen? Standheizung?...
[Bestätigung]

...usw bis Block 7

Block 8 - Freitext: "Was haben wir noch nicht erwähnt?"
```

## Mapping zum PDF

Im Bewertungs-PDF werden nur die "Highlights" der Ausstattung gezeigt (max. 8 Items), priorisiert nach Wertrelevanz:

1. Panoramadach/Schiebedach
2. Lederausstattung
3. Licht-Typ (LED/Matrix/Laser)
4. Navigation (Werks)
5. Kamera (360° hat Vorrang vor Rück)
6. Soundsystem (wenn Premium-Marke)
7. AHK (mit Typ)
8. Werksgarantie (wenn aktiv)

Die volle Liste wird in der JSON-Akte gespeichert und kann auf Wunsch ins PDF aufgenommen werden.
