# Akte-Schema (JSON)

Die Akte ist eine JSON-Datei, die alle Daten zum Fahrzeug enthält und mit jedem Schritt ergänzt wird.

## Vollständiges Schema

```python
akte = {
    # === Metadaten ===
    "akten_id": "Csontos_Tucson_011029",   # auto-generiert
    "status": "DATENAUFNAHME",              # NEU | DATENAUFNAHME | IN_WERKSTATT | ZUR_KALKULATION | ANGEKAUFT | UEBERNOMMEN
    "erstellt_am": "2026-05-08T14:30:00",
    "geaendert_am": "2026-05-08T15:45:00",
    "stufe1_abgeschlossen_am": None,
    "stufe2_abgeschlossen_am": None,
    "stufe3_abgeschlossen_am": None,
    "stufe4_abgeschlossen_am": None,

    # === STUFE 1: KUNDE / VERKÄUFER ===
    "verkaeufer": {
        "name": "Aleksander Csontos",       # vollständiger Name
        "strasse": "Hauptstraße 57",
        "plz_ort": "79341 Kenzingen",
        "telefon": "",                      # optional
        "email": "",                        # optional
        "kunden_nr": "3990023",             # falls vorhanden
    },

    # === STUFE 1: FAHRZEUG (aus ZLB) ===
    "fahrzeug": {
        "hersteller": "Hyundai",
        "modell": "Tucson",
        "variante": "",                     # z.B. "N-Line"
        "aufbau": "SUV",
        "farbe": "Grau",
        "fin": "TMAJE81BGMJ011029",         # 17 Zeichen
        "kennzeichen": "EM NA2004",
        "erstzulassung": "30.04.2021",      # DD.MM.YYYY
        "km_stand": "60.773",               # mit Tausender-Punkt, ohne "km"
        "hubraum_ccm": "1.598",
        "leistung_kw": "130",
        "leistung_ps": "177",
        "kraftstoff": "Benzin",             # Benzin | Diesel | Elektro | Hybrid | Plug-in-Hybrid
        "getriebe": "Automatik",
        "antrieb": "4WD",                   # 2WD | 4WD
        "halteranzahl": "2",
        "schadstoffklasse": "EURO 6 (WLTP)",
    },

    # === STUFE 1: EXTRAS-CHECKLISTE ===
    "extras": {
        # Block 1: Sitze & Komfort
        "panoramadach": False,
        "schiebedach": False,
        "lederausstattung": "Stoff",       # "Voll" | "Teil" | "Stoff"
        "sitzheizung_vorne": True,
        "sitzheizung_hinten": False,
        "sitzbelueftung": False,
        "elektrische_sitze": "Nein",       # "Beide" | "Fahrer" | "Nein"
        "sitz_memory": False,
        # Block 2: Klima
        "klimaautomatik": "2",             # "1" | "2" | "3" | "4" | "Manuell"
        "lenkradheizung": False,
        "standheizung": "Nein",            # "Werks" | "Nachgerüstet" | "Nein"
        # Block 3: Multimedia
        "navigation": "Werks",             # "Werks" | "Smartphone" | "Nein"
        "apple_carplay_android_auto": True,
        "dab_radio": True,
        "bluetooth": True,
        "soundsystem": "",                 # Marke z.B. "Bose", "" wenn Standard
        # Block 4: Licht
        "licht_typ": "LED",                # "LED" | "Matrix-LED" | "Laser" | "Xenon" | "Halogen"
        "head_up_display": False,
        "rueckfahrkamera": True,
        "kamera_360": False,
        # Block 5: Assistenz
        "eph_vorne": True,
        "eph_hinten": True,
        "park_assistent": False,
        "adaptive_cruise": True,
        "spurhalteassistent": True,
        # Block 6: Komfort
        "keyless_go": True,
        "elektr_heckklappe": "Ja",         # "Mit Sensor" | "Ja" | "Nein"
        "ahk": "Nein",                     # "Fest" | "Abnehmbar" | "Elektrisch" | "Nein"
        # Block 7: Räder / Garantie
        "alufelgen_sommer": True,
        "alufelgen_zoll": "19",
        "winterreifen_vorhanden": False,
        "winterreifen_art": "",            # "Alu" | "Stahl" | ""
        "werksgarantie_aktiv": False,
        "werksgarantie_bis": "",           # MM/YYYY
        # Freitext
        "extras_freitext": "",
    },

    # === STUFE 2: WERKSTATT-DURCHSICHT ===
    "werkstatt": {
        "durchgesehen_von": "",            # Name des Meisters
        "durchgesehen_am": "",             # DD.MM.YYYY
        "hu_faellig": "05/2026",           # MM/YYYY
        "kd_faellig": "05/2026",           # MM/YYYY
        "alle_kd_durchgefuehrt": True,
        "unfallfrei": True,
        "hagelschaden": False,
        "nachlackiert": False,
        "ex_mietwagen": False,
        "eu_fahrzeug": False,
        "gebrauchsspuren": True,
    },

    "maengel": [
        {
            "pos": 1,
            "baugruppe": "HU/TÜV",
            "beschreibung": "HU und Inspektion 05/2026 fällig",
        },
        # weitere...
    ],

    "positive_notizen": "",                # frei formulierbar

    # === STUFE 3: KALKULATION ===
    "kalkulation": {
        "kalkuliert_von": "",              # Name (meist "Oliver Stieber")
        "kalkuliert_am": "",
        "aufwendungen_gesamt": 0.00,       # 0 = pauschal, kein Betrag im PDF
        "haendlereinkaufspreis": 16500.00,
        "vertrags_nr": "KV-2026-Tucson-011029",
        "bewertungs_nr": "FB-2026-Tucson-011029",
    },

    # === STUFE 4: FAHRZEUG-ÜBERGABE ===
    "uebergabe": {
        "uebergabe_am": "",                # DD.MM.YYYY
        "uebergabe_durch": "",             # Name
        "km_stand_uebergabe": "",          # bei Anlieferung
        "km_differenz": "",                # auto-berechnet
        "tankstand": "",                   # "leer" | "1/4" | "1/2" | "3/4" | "voll"
        "anzahl_schluessel": "2",
        "bordmappe_vorhanden": True,
        "serviceheft_vorhanden": True,
        "kfz_schein_vorhanden": True,
        "kfz_brief_vorhanden": True,
        "winterreifen_mitgebracht": False,
        "winterreifen_zustand": "",
        "neue_schaeden": "",               # Freitext
        "allgemeiner_zustand": "",         # "i.O." | "leichte Abweichung" | "signifikante Abweichung"
        "fotos_hinzugefuegt": False,       # Hinweis dass Fotos extern abgelegt wurden
        "bemerkungen": "",
    },
}
```

## Datei-Naming

Die `akten_id` wird automatisch erzeugt:

```python
def make_akten_id(verkaeufer_name, modell, fin):
    nachname = verkaeufer_name.strip().split()[-1]   # letztes Wort = Nachname
    nachname = re.sub(r"[^A-Za-zÄÖÜäöüß]", "", nachname)  # nur Buchstaben
    modell_clean = re.sub(r"\s+", "", modell)
    last6 = fin[-6:]
    return f"{nachname}_{modell_clean}_{last6}"
```

Beispiele:
- `Csontos_Tucson_011029`
- `Doell_TucsonN-Line_133631`
- `Mueller_320d_445566`

## Pflichtfelder pro Stufe

| Stufe | Erforderliche Felder |
|-------|----------------------|
| 1 | verkaeufer.name, verkaeufer.strasse, verkaeufer.plz_ort, fahrzeug.hersteller, fahrzeug.modell, fahrzeug.fin (17), fahrzeug.kennzeichen, fahrzeug.erstzulassung, fahrzeug.km_stand |
| 2 | werkstatt.hu_faellig, mind. 1 Mangel ODER explizit "keine Mängel" |
| 3 | kalkulation.haendlereinkaufspreis |
| 4 | uebergabe.km_stand_uebergabe, uebergabe.tankstand, uebergabe.anzahl_schluessel |
