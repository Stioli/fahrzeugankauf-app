---
name: fahrzeugankauf-akte
description: Umfassendes 4-Stufen-Aktensystem für den Fahrzeugankauf der Autohaus Stieber GmbH – Datenaufnahme beim Kunden (Stufe 1), Werkstatt-Durchsicht mit Mängelerfassung (Stufe 2), Kalkulation und Ankauf-PDF-Generierung (Stufe 3) sowie Fahrzeug-Übergabeprotokoll bei Anlieferung (Stufe 4). Verwende diesen Skill IMMER wenn Oli oder ein Mitarbeiter ein neues Fahrzeug ankaufen, eine bestehende Akte fortführen, Mängel dokumentieren, einen Ankauf kalkulieren, einen Kaufvertrag erstellen oder ein Fahrzeug bei Anlieferung kontrollieren möchte. Trigger-Wörter: "Akte anlegen", "Fahrzeugankauf", "neue Akte", "Akte fortführen", "Werkstatt-Durchsicht", "Mängel erfassen", "Ankauf kalkulieren", "Kaufvertrag erstellen", "Fahrzeug-Übergabe", "Übergabeprotokoll", "Zustandsbericht Anlieferung", "Inzahlungnahme", "Tablet-Aufnahme", "Extras-Checkliste", sowie wenn ein Fahrzeugschein (ZLB) zur Datenaufnahme hochgeladen wird. Dieser Skill löst den älteren `inzahlungnahme-bewertung` Skill ab und integriert dessen Funktionalität.
---

# Fahrzeugankauf-Akte – Komplettes 4-Stufen-System für Autohaus Stieber

## Zweck

Dieser Skill bildet den gesamten Fahrzeugankauf-Prozess von der ersten Kundenanfrage bis zur Fahrzeug-Übernahme ab. Pro Fahrzeug wird eine eigene **Akte** geführt (JSON-Datei + zugehörige PDFs), die schrittweise durch 4 Stufen läuft.

## Akten-Konzept

Jede Akte ist eine JSON-Datei mit allen Daten zum Fahrzeug und Status-Tracking. Pro Akte gehören folgende Dateien zusammen, alle mit gleichem Basisnamen:

- `<Nachname>_<Modell>_<Letzte6FIN>.json` – die Akten-Datei
- `<Nachname>_<Modell>_<Letzte6FIN>_Bewertung.pdf` – Fahrzeugbewertung (Stufe 3)
- `<Nachname>_<Modell>_<Letzte6FIN>_Kaufvertrag.pdf` – Kaufvertrag (Stufe 3)
- `<Nachname>_<Modell>_<Letzte6FIN>_Uebergabe.pdf` – Übergabeprotokoll (Stufe 4)

Ablage-Ordner (manuell vom Nutzer):  
`C:\Users\oliver.stieber\OneDrive - Autohaus Stieber\Autohaus Stieber\Fahrzeugverkauf\Fahrzeuge\Inzahlungnahme+Ankauf\<Akte>\`

## Status-Flow

```
NEU → DATENAUFNAHME → IN_WERKSTATT → ZUR_KALKULATION → ANGEKAUFT → UEBERNOMMEN
```

## Workflow

### Stufe 1: Datenaufnahme (Verkaufsberater am Tablet)

Verwende `scripts/akte_neu.py` oder lese den ZLB via Vision aus.

1. **Fahrzeugschein-Foto auswerten:** Wenn der Nutzer eine ZLB hochlädt, lies systematisch aus (siehe `references/zlb-mapping.md`).
2. **Halter-Daten erfassen:** Name, Adresse, Telefon, E-Mail, Kunden-Nr.
3. **Extras-Checkliste durchgehen:** Verwende die strukturierte Liste in `references/extras-checkliste.md`. Frage Oli systematisch durch — Gruppe für Gruppe (Sitze/Komfort, Multimedia, Licht/Sicht, Assistenz, Anhängelast, Sonstiges) — und bestätige nach jeder Gruppe.
4. **Akte speichern** mit Status `DATENAUFNAHME` oder `IN_WERKSTATT` (wenn Fahrzeug bereits in Werkstatt).

### Stufe 2: Werkstatt-Durchsicht (Meister)

1. Akte öffnen: `scripts/akte_oeffnen.py <pfad>` oder Daten aus dem Chat-Verlauf nehmen.
2. **Mängel erfassen** – mehrere Eingangswege:
   - Direktannahmebericht-PDF hochladen → automatische Mängel-Vorschläge nach Mapping (`references/maengel-mapping.md`)
   - Manuell durch den Meister angegeben (Liste)
   - Kombination aus beidem
3. KD-Termin und HU-Datum eintragen.
4. Status auf `ZUR_KALKULATION` setzen.

### Stufe 3: Kalkulation (Geschäftsführer Oliver)

1. Akte öffnen.
2. **Pauschale Aufwendungen** im PDF anzeigen (kein Einzelpreis pro Mangel!) — falls Oli intern kalkuliert hat, optional den Gesamtbetrag erfassen.
3. **Händler-Einkaufspreis** festlegen.
4. **Bewertungs-PDF + Kaufvertrag-PDF** generieren via `scripts/generate_ankauf_pdfs.py`.
5. Status auf `ANGEKAUFT` setzen.

### Stufe 4: Fahrzeug-Übergabe (bei Anlieferung)

1. Akte öffnen.
2. **Zustandsbericht erfassen:**
   - KM-Stand bei Übergabe (Vergleich mit Bewertung – Differenz zeigen)
   - Tankstand (1/4, 1/2, 3/4, voll, leer)
   - Anzahl Schlüssel (1, 2 oder mehr)
   - Bordmappe / Serviceheft / KFZ-Schein vorhanden
   - Winterreifen mitgebracht (ja/nein, wenn ja: Zustand)
   - **Neue Schäden seit Bewertung** (Freitext)
   - Allgemeiner Zustand (i.O. / leichte Abweichung / signifikante Abweichung)
   - Ggf. Foto-Hinweis (Fotos manuell vom Nutzer in Akten-Ordner abgelegt)
3. **Übergabe-PDF** generieren via `scripts/generate_uebergabe_pdf.py`.
4. Status auf `UEBERNOMMEN` setzen → Akte abgeschlossen.

## Pflicht-Reihenfolge bei Akten-Aktionen

1. Vor JEDER Stufe: aktuelle Akten-Daten anzeigen, damit der Nutzer Kontext hat.
2. Bei Mehrfach-Eingabe (z.B. Extras): immer Block-weise bestätigen lassen, nicht alle 30 auf einmal abfragen.
3. Vor PDF-Generierung: Validierung der Daten ausgeben (was fehlt? was ist OK?).
4. Nach PDF-Generierung: Speicheranweisung für OneDrive-Ordner zeigen.

## Datenformat der Akte

Siehe `references/akte-schema.md` für das vollständige JSON-Schema.

## Speicheranweisung an Oli (nach jedem PDF)

Nach jeder PDF-Generierung gib eine kurze Anweisung:

> Bitte die Datei in deinen OneDrive-Ordner ablegen:
> `OneDrive\Autohaus Stieber\Fahrzeugverkauf\Fahrzeuge\Inzahlungnahme+Ankauf\<Nachname>_<Modell>_<Letzte6FIN>\`
>
> Wenn der Akten-Ordner noch nicht existiert, lege ihn dort an.

## Bundled Resources

- `SKILL.md` – diese Datei
- `scripts/akte_neu.py` – Akte anlegen / Stufe 1
- `scripts/akte_oeffnen.py` – bestehende Akte laden
- `scripts/akte_speichern.py` – Akte als JSON speichern
- `scripts/generate_ankauf_pdfs.py` – Bewertung + Kaufvertrag (Stufe 3)
- `scripts/generate_uebergabe_pdf.py` – Übergabeprotokoll (Stufe 4)
- `templates/bewertung_kaufvertrag.html` – HTML-Template Stufe 3
- `templates/uebergabe.html` – HTML-Template Stufe 4
- `assets/logo.jpg` – Stieber-Logo
- `references/zlb-mapping.md` – Fahrzeugschein-Felder
- `references/extras-checkliste.md` – die ~30 Standard-Extras
- `references/maengel-mapping.md` – Direktannahme → Mängel-Mapping
- `references/akte-schema.md` – JSON-Akten-Datenmodell
- `references/kaufvertrag-pflichtbestandteile.md` – juristische Grundlagen

## Kommunikation mit Oli und Mitarbeitern

- Immer auf **Deutsch**, informell ("du")
- Tablet-tauglich denken: kurze Listen, klare Bestätigungen, keine endlosen Texte
- Nach jeder Stufe kurze Zusammenfassung + nächster Schritt
- Bei Unsicherheit immer nachfragen statt raten
