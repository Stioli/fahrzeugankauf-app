#!/usr/bin/env python3
"""
Generator für Bewertung + Kaufvertrag (Stufe 3 des Fahrzeugankauf-Systems).

Liest eine Akte (dict) und erzeugt das 2-seitige PDF im Stieber-Corporate-Design.

Verwendung:
    from generate_ankauf_pdfs import generate_ankauf_pdf
    pfad = generate_ankauf_pdf(akte)
"""

import os
import sys
from pathlib import Path
from datetime import datetime
from jinja2 import Environment, FileSystemLoader

try:
    from weasyprint import HTML
except ImportError:
    print("WeasyPrint nicht installiert. Installiere mit:")
    print("  pip install weasyprint jinja2 --break-system-packages")
    sys.exit(1)


# ===========================================================================
# Hilfsfunktionen: Zahlen in Worten (für Kaufvertrag § 2)
# ===========================================================================

def _einer(n: int) -> str:
    woerter = ["null", "ein", "zwei", "drei", "vier", "fünf", "sechs", "sieben", "acht", "neun"]
    return woerter[n]


def _zehner(n: int) -> str:
    if n < 10:
        return _einer(n)
    if n < 20:
        special = {10: "zehn", 11: "elf", 12: "zwölf", 13: "dreizehn", 14: "vierzehn",
                   15: "fünfzehn", 16: "sechzehn", 17: "siebzehn", 18: "achtzehn", 19: "neunzehn"}
        return special[n]
    zehner = {2: "zwanzig", 3: "dreißig", 4: "vierzig", 5: "fünfzig", 6: "sechzig",
              7: "siebzig", 8: "achtzig", 9: "neunzig"}
    z, e = divmod(n, 10)
    if e == 0:
        return zehner[z]
    return f"{_einer(e)}und{zehner[z]}"


def _zahl_bis_999(n: int) -> str:
    if n < 100:
        return _zehner(n)
    h, r = divmod(n, 100)
    result = "einhundert" if h == 1 else f"{_einer(h)}hundert"
    if r:
        result += _zehner(r)
    return result


def zahl_zu_worten(n: int) -> str:
    if n == 0:
        return "null"
    if n >= 1_000_000:
        return f"{n}"
    if n < 1000:
        return _zahl_bis_999(n)
    t, r = divmod(n, 1000)
    result = "eintausend" if t == 1 else f"{_zahl_bis_999(t)}tausend"
    if r:
        result += _zahl_bis_999(r)
    return result


def betrag_in_worten(euro: float) -> str:
    n = int(round(euro))
    wort = zahl_zu_worten(n)
    return f"{wort[0].upper()}{wort[1:]} Euro"


def euro_de(betrag: float) -> str:
    """Formatiert 12345.5 -> '12.345,50'"""
    s = f"{betrag:,.2f}"
    s = s.replace(",", "§").replace(".", ",").replace("§", ".")
    return s


# ===========================================================================
# Akte → Template-Daten (Adapter)
# ===========================================================================

def akte_zu_template_daten(akte: dict) -> dict:
    """
    Wandelt die Akten-Struktur in das Template-Format des HTML-Renderers um.
    """
    f = akte["fahrzeug"]
    v = akte["verkaeufer"]
    e = akte["extras"]
    w = akte["werkstatt"]
    k = akte["kalkulation"]

    # Ausstattung-Mapping: aus Extras-Liste die "Highlights" für PDF
    ausstattung_pdf = {
        "navigation": e.get("navigation") in ("Werks", "Smartphone"),
        "eph_vorne": e.get("eph_vorne", False),
        "eph_hinten": e.get("eph_hinten", False),
        "rueckfahrkamera": e.get("rueckfahrkamera", False) or e.get("kamera_360", False),
        "alufelgen_sommer": e.get("alufelgen_sommer", False),
        "winterreifen": e.get("winterreifen_vorhanden", False),
        "winterreifen_art": e.get("winterreifen_art", ""),
        "pano_schiebedach": e.get("panoramadach", False) or e.get("schiebedach", False),
        "ahk": e.get("ahk", "Nein") != "Nein",
        "sitzheizung": e.get("sitzheizung_vorne", False),
        "werksgarantie_aktiv": e.get("werksgarantie_aktiv", False),
    }

    # Fahrzeug-Daten mit den Werkstatt-Feldern zusammenführen (für Template)
    fahrzeug_pdf = dict(f)
    fahrzeug_pdf.update({
        "hu_faellig": w.get("hu_faellig", ""),
        "kd_faellig": w.get("kd_faellig", ""),
        "alle_kd_durchgefuehrt": w.get("alle_kd_durchgefuehrt", False),
        "unfallfrei": w.get("unfallfrei", True),
        "hagelschaden": w.get("hagelschaden", False),
        "nachlackiert": w.get("nachlackiert", False),
        "ex_mietwagen": w.get("ex_mietwagen", False),
        "eu_fahrzeug": w.get("eu_fahrzeug", False),
    })

    # Bekannte-Mängel-Text aus dokumentierten Mängeln
    if akte["maengel"]:
        bekannte_maengel = " · ".join(m["beschreibung"] for m in akte["maengel"]
                                       if m["baugruppe"] != "Aufbereitung")
    else:
        bekannte_maengel = "Keine Mängel bekannt"

    # Quellen-Hinweis
    quelle = "Werkstatt-Durchsicht"
    if w.get("durchgesehen_am"):
        quelle += f" vom {w['durchgesehen_am']}"
    if w.get("durchgesehen_von"):
        quelle += f" ({w['durchgesehen_von']})"

    # Vertrags-Nummern auto-generieren wenn leer
    jahr = datetime.now().year
    last6 = f["fin"][-6:] if f.get("fin") else "------"
    vertrags_nr = k.get("vertrags_nr") or f"KV-{jahr}-{last6}"
    bewertungs_nr = k.get("bewertungs_nr") or f"FB-{jahr}-{last6}"

    return {
        "dok_datum": k.get("kalkuliert_am") or datetime.now().strftime("%d.%m.%Y"),
        "vertrags_nr": vertrags_nr,
        "bewertungs_nr": bewertungs_nr,
        "verkaeufer": v,
        "fahrzeug": fahrzeug_pdf,
        "ausstattung": ausstattung_pdf,
        "maengel": akte["maengel"],
        "aufwendungen_gesamt": float(k.get("aufwendungen_gesamt", 0.00)),
        "positive_notizen": akte.get("positive_notizen", ""),
        "haendlereinkaufspreis": float(k.get("haendlereinkaufspreis", 0.00)),
        "bekannte_maengel_text": bekannte_maengel,
        "quelle_direktannahme": quelle,
    }


# ===========================================================================
# PDF-Generierung
# ===========================================================================

def generate_ankauf_pdf(akte: dict, output_path: str = None) -> str:
    """
    Erzeugt das 2-seitige Ankauf-PDF (Bewertung + Kaufvertrag).

    Args:
        akte: Akten-Dict
        output_path: optional, sonst aus akten_id generiert

    Returns:
        Pfad der erzeugten PDF-Datei.
    """
    data = akte_zu_template_daten(akte)

    # Output-Pfad
    if output_path is None:
        akten_id = akte.get("akten_id") or "Akte"
        output_path = f"/mnt/user-data/outputs/{akten_id}_Bewertung_Kaufvertrag.pdf"

    # Display-Werte
    einkaufspreis = float(data["haendlereinkaufspreis"])
    aufwendungen = float(data["aufwendungen_gesamt"])
    data["einkaufspreis_display"] = euro_de(einkaufspreis)
    data["aufwendungen_display"] = euro_de(aufwendungen)
    data["betrag_in_worten"] = betrag_in_worten(einkaufspreis)

    # Logo-Pfad
    skill_root = Path(__file__).resolve().parent.parent
    logo_file = skill_root / "assets" / "logo.jpg"
    data["logo_path"] = f"file://{logo_file}" if logo_file.exists() else ""

    # Defaults für Template
    data.setdefault("dok_titel", "Bewertung & Kaufvertrag")

    # Template rendern
    template_dir = skill_root / "templates"
    env = Environment(loader=FileSystemLoader(str(template_dir)))
    template = env.get_template("bewertung_kaufvertrag.html")
    html_content = template.render(**data)

    # PDF schreiben
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    HTML(string=html_content, base_url=str(template_dir)).write_pdf(output_path)

    return output_path


# ===========================================================================
# CLI für Test
# ===========================================================================

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from akte import neue_akte

    akte = neue_akte()
    akte["akten_id"] = "Test_Tucson_011029"
    akte["verkaeufer"]["name"] = "Aleksander Csontos"
    akte["verkaeufer"]["strasse"] = "Hauptstraße 57"
    akte["verkaeufer"]["plz_ort"] = "79341 Kenzingen"
    akte["fahrzeug"].update({
        "hersteller": "Hyundai", "modell": "Tucson",
        "fin": "TMAJE81BGMJ011029", "kennzeichen": "EM NA2004",
        "erstzulassung": "30.04.2021", "km_stand": "60.773",
        "hubraum_ccm": "1.598", "leistung_kw": "148", "leistung_ps": "201",
        "kraftstoff": "Hybrid", "getriebe": "Automatik", "antrieb": "4WD",
        "halteranzahl": "2", "farbe": "Grau", "schadstoffklasse": "EURO 6 (WLTP)",
    })
    akte["werkstatt"]["hu_faellig"] = "05/2026"
    akte["maengel"] = [
        {"pos": 1, "baugruppe": "HU/TÜV", "beschreibung": "HU und Inspektion 05/2026 fällig"},
        {"pos": 2, "baugruppe": "Aufbereitung", "beschreibung": "Fahrzeugaufbereitung innen/außen"},
    ]
    akte["kalkulation"]["haendlereinkaufspreis"] = 16500.00

    pfad = generate_ankauf_pdf(akte)
    print(f"PDF erstellt: {pfad}")
