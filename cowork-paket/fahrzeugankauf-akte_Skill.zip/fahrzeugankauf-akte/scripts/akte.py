"""
Akte-Verwaltung für Fahrzeugankauf — Stieber Autohaus GmbH

Pro Fahrzeug eine Akte (JSON-Datei) mit allen Daten und Status-Tracking.
"""
import json
import re
from datetime import datetime
from pathlib import Path


# ===========================================================================
# Status-Konstanten
# ===========================================================================

STATUS_NEU = "NEU"
STATUS_DATENAUFNAHME = "DATENAUFNAHME"
STATUS_IN_WERKSTATT = "IN_WERKSTATT"
STATUS_ZUR_KALKULATION = "ZUR_KALKULATION"
STATUS_ANGEKAUFT = "ANGEKAUFT"
STATUS_UEBERNOMMEN = "UEBERNOMMEN"

STATUS_LABELS = {
    STATUS_NEU: "Neu",
    STATUS_DATENAUFNAHME: "Datenaufnahme",
    STATUS_IN_WERKSTATT: "In Werkstatt",
    STATUS_ZUR_KALKULATION: "Zur Kalkulation",
    STATUS_ANGEKAUFT: "Angekauft",
    STATUS_UEBERNOMMEN: "Übernommen",
}


# ===========================================================================
# Akten-ID generieren
# ===========================================================================

def make_akten_id(verkaeufer_name: str, modell: str, fin: str) -> str:
    """
    Erzeugt eine eindeutige Akten-ID nach Schema:
    <Nachname>_<Modell>_<Letzte6FIN>

    Beispiel: "Csontos_Tucson_011029"
    """
    # Nachname = letztes Wort
    nachname = verkaeufer_name.strip().split()[-1] if verkaeufer_name.strip() else "Unbekannt"
    # Nur Buchstaben (auch Umlaute), keine Sonderzeichen
    nachname = re.sub(r"[^A-Za-zÄÖÜäöüß]", "", nachname)
    if not nachname:
        nachname = "Unbekannt"

    # Modell ohne Leerzeichen
    modell_clean = re.sub(r"\s+", "", modell or "Unbekannt")
    modell_clean = re.sub(r"[^A-Za-z0-9\-]", "", modell_clean)

    # Letzte 6 Zeichen der FIN
    fin_clean = (fin or "").strip().upper()
    last6 = fin_clean[-6:] if len(fin_clean) >= 6 else fin_clean.zfill(6)

    return f"{nachname}_{modell_clean}_{last6}"


# ===========================================================================
# Akten-Datei: Pfad-Schema
# ===========================================================================

OUTPUT_DIR = Path("/mnt/user-data/outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

ONEDRIVE_BASE = (
    r"C:\Users\oliver.stieber\OneDrive - Autohaus Stieber\Autohaus Stieber"
    r"\Fahrzeugverkauf\Fahrzeuge\Inzahlungnahme+Ankauf"
)


def get_onedrive_pfad(akten_id: str) -> str:
    """Gibt den Ziel-Pfad im OneDrive-Ordner zurück (für Anweisungen an Oli)."""
    return f"{ONEDRIVE_BASE}\\{akten_id}\\"


def get_lokaler_pfad(akten_id: str, suffix: str = ".json") -> Path:
    """Lokaler Output-Pfad für Download."""
    return OUTPUT_DIR / f"{akten_id}{suffix}"


# ===========================================================================
# Leere Akte initialisieren
# ===========================================================================

def neue_akte() -> dict:
    """Erzeugt eine leere Akten-Struktur (alle Pflichtfelder vorhanden)."""
    now = datetime.now().isoformat(timespec="seconds")
    return {
        "akten_id": "",
        "status": STATUS_NEU,
        "erstellt_am": now,
        "geaendert_am": now,
        "stufe1_abgeschlossen_am": None,
        "stufe2_abgeschlossen_am": None,
        "stufe3_abgeschlossen_am": None,
        "stufe4_abgeschlossen_am": None,

        "verkaeufer": {
            "name": "",
            "strasse": "",
            "plz_ort": "",
            "telefon": "",
            "email": "",
            "kunden_nr": "",
        },

        "fahrzeug": {
            "hersteller": "",
            "modell": "",
            "variante": "",
            "aufbau": "",
            "farbe": "",
            "fin": "",
            "kennzeichen": "",
            "erstzulassung": "",
            "km_stand": "",
            "hubraum_ccm": "",
            "leistung_kw": "",
            "leistung_ps": "",
            "kraftstoff": "",
            "getriebe": "",
            "antrieb": "",
            "halteranzahl": "",
            "schadstoffklasse": "",
        },

        "extras": {
            # Block 1: Sitze & Komfort
            "panoramadach": False,
            "schiebedach": False,
            "lederausstattung": "Stoff",
            "sitzheizung_vorne": False,
            "sitzheizung_hinten": False,
            "sitzbelueftung": False,
            "elektrische_sitze": "Nein",
            "sitz_memory": False,
            # Block 2: Klima
            "klimaautomatik": "Manuell",
            "lenkradheizung": False,
            "standheizung": "Nein",
            # Block 3: Multimedia
            "navigation": "Nein",
            "apple_carplay_android_auto": False,
            "dab_radio": False,
            "bluetooth": False,
            "soundsystem": "",
            # Block 4: Licht
            "licht_typ": "Halogen",
            "head_up_display": False,
            "rueckfahrkamera": False,
            "kamera_360": False,
            # Block 5: Assistenz
            "eph_vorne": False,
            "eph_hinten": False,
            "park_assistent": False,
            "adaptive_cruise": False,
            "spurhalteassistent": False,
            # Block 6: Komfort
            "keyless_go": False,
            "elektr_heckklappe": "Nein",
            "ahk": "Nein",
            # Block 7: Räder / Garantie
            "alufelgen_sommer": False,
            "alufelgen_zoll": "",
            "winterreifen_vorhanden": False,
            "winterreifen_art": "",
            "werksgarantie_aktiv": False,
            "werksgarantie_bis": "",
            # Freitext
            "extras_freitext": "",
        },

        "werkstatt": {
            "durchgesehen_von": "",
            "durchgesehen_am": "",
            "hu_faellig": "",
            "kd_faellig": "",
            "alle_kd_durchgefuehrt": False,
            "unfallfrei": True,
            "hagelschaden": False,
            "nachlackiert": False,
            "ex_mietwagen": False,
            "eu_fahrzeug": False,
            "gebrauchsspuren": False,
        },

        "maengel": [],
        "positive_notizen": "",

        "kalkulation": {
            "kalkuliert_von": "",
            "kalkuliert_am": "",
            "aufwendungen_gesamt": 0.00,
            "haendlereinkaufspreis": 0.00,
            "vertrags_nr": "",
            "bewertungs_nr": "",
        },

        "uebergabe": {
            "uebergabe_am": "",
            "uebergabe_durch": "",
            "km_stand_uebergabe": "",
            "km_differenz": "",
            "tankstand": "",
            "anzahl_schluessel": "",
            "bordmappe_vorhanden": False,
            "serviceheft_vorhanden": False,
            "kfz_schein_vorhanden": False,
            "kfz_brief_vorhanden": False,
            "winterreifen_mitgebracht": False,
            "winterreifen_zustand": "",
            "neue_schaeden": "",
            "allgemeiner_zustand": "",
            "fotos_hinzugefuegt": False,
            "bemerkungen": "",
        },
    }


# ===========================================================================
# Akte speichern / laden
# ===========================================================================

def akte_speichern(akte: dict) -> Path:
    """
    Speichert die Akte als JSON in /mnt/user-data/outputs/.
    Setzt automatisch akten_id (falls noch leer) und geaendert_am.
    """
    # akten_id setzen wenn leer
    if not akte.get("akten_id"):
        akte["akten_id"] = make_akten_id(
            akte["verkaeufer"]["name"],
            akte["fahrzeug"]["modell"],
            akte["fahrzeug"]["fin"],
        )

    # Aktualisiert-Stempel
    akte["geaendert_am"] = datetime.now().isoformat(timespec="seconds")

    pfad = get_lokaler_pfad(akte["akten_id"], ".json")
    pfad.write_text(json.dumps(akte, indent=2, ensure_ascii=False), encoding="utf-8")
    return pfad


def akte_laden(pfad: str | Path) -> dict:
    """Lädt eine Akten-Datei."""
    pfad = Path(pfad)
    if not pfad.exists():
        raise FileNotFoundError(f"Akte nicht gefunden: {pfad}")
    return json.loads(pfad.read_text(encoding="utf-8"))


# ===========================================================================
# Status-Übergänge
# ===========================================================================

def status_setzen(akte: dict, neuer_status: str) -> dict:
    """Setzt den Status und den entsprechenden Zeitstempel."""
    akte["status"] = neuer_status
    now = datetime.now().isoformat(timespec="seconds")

    if neuer_status == STATUS_IN_WERKSTATT and not akte.get("stufe1_abgeschlossen_am"):
        akte["stufe1_abgeschlossen_am"] = now
    elif neuer_status == STATUS_ZUR_KALKULATION and not akte.get("stufe2_abgeschlossen_am"):
        akte["stufe2_abgeschlossen_am"] = now
    elif neuer_status == STATUS_ANGEKAUFT and not akte.get("stufe3_abgeschlossen_am"):
        akte["stufe3_abgeschlossen_am"] = now
    elif neuer_status == STATUS_UEBERNOMMEN and not akte.get("stufe4_abgeschlossen_am"):
        akte["stufe4_abgeschlossen_am"] = now

    return akte


# ===========================================================================
# Validierung pro Stufe
# ===========================================================================

def validiere_stufe1(akte: dict) -> list[str]:
    """Pflichtfelder für Stufe 1 prüfen. Gibt Liste fehlender Felder zurück."""
    fehler = []
    v = akte["verkaeufer"]
    f = akte["fahrzeug"]

    if not v["name"].strip(): fehler.append("Verkäufer-Name fehlt")
    if not v["strasse"].strip(): fehler.append("Verkäufer-Straße fehlt")
    if not v["plz_ort"].strip(): fehler.append("Verkäufer-PLZ/Ort fehlt")
    if not f["hersteller"].strip(): fehler.append("Fahrzeug-Hersteller fehlt")
    if not f["modell"].strip(): fehler.append("Fahrzeug-Modell fehlt")
    if len(f["fin"].strip()) != 17: fehler.append("FIN muss exakt 17 Zeichen haben")
    if not f["kennzeichen"].strip(): fehler.append("Kennzeichen fehlt")
    if not f["erstzulassung"].strip(): fehler.append("Erstzulassung fehlt")
    if not f["km_stand"].strip(): fehler.append("KM-Stand fehlt")

    return fehler


def validiere_stufe3(akte: dict) -> list[str]:
    """Pflichtfelder für Stufe 3 (Kalkulation + PDFs)."""
    fehler = validiere_stufe1(akte)
    k = akte["kalkulation"]
    if k["haendlereinkaufspreis"] <= 0:
        fehler.append("Händler-Einkaufspreis muss > 0 sein")
    if not akte["maengel"] and akte["kalkulation"]["aufwendungen_gesamt"] > 0:
        fehler.append("Aufwendungen > 0, aber keine Mängel dokumentiert")
    return fehler


def validiere_stufe4(akte: dict) -> list[str]:
    """Pflichtfelder für Stufe 4 (Übergabe)."""
    fehler = []
    u = akte["uebergabe"]
    if not u["km_stand_uebergabe"]: fehler.append("KM-Stand bei Übergabe fehlt")
    if not u["tankstand"]: fehler.append("Tankstand fehlt")
    if not u["anzahl_schluessel"]: fehler.append("Anzahl Schlüssel fehlt")
    return fehler


# ===========================================================================
# Hilfsfunktionen
# ===========================================================================

def kw_zu_ps(kw: int | str) -> int:
    """Konvertiert Leistung kW → PS."""
    try:
        return round(int(kw) * 1.359621617)
    except (ValueError, TypeError):
        return 0


def fahrzeug_kurzname(akte: dict) -> str:
    """Kompakte Fahrzeugbezeichnung für Anzeige."""
    f = akte["fahrzeug"]
    teile = [f["hersteller"], f["modell"]]
    if f["variante"]:
        teile.append(f["variante"])
    return " ".join(t for t in teile if t)
