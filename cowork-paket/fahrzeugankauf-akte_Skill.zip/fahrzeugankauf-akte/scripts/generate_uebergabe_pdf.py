#!/usr/bin/env python3
"""
Generator für Fahrzeug-Übergabeprotokoll (Stufe 4 des Fahrzeugankauf-Systems).

Erzeugt ein 1-seitiges PDF mit Zustandskontrolle bei Anlieferung.
"""

import sys
from pathlib import Path
from datetime import datetime
from jinja2 import Environment, FileSystemLoader

try:
    from weasyprint import HTML
except ImportError:
    print("WeasyPrint nicht installiert. Installiere mit:")
    print("  pip install weasyprint jinja2 --break-system-packages")
    sys.exit(1)


# ===========================================================================
# KM-Differenz berechnen
# ===========================================================================

def km_differenz(km_bewertung_str: str, km_uebergabe_str: str) -> int:
    """Berechnet KM-Differenz zwischen Bewertung und Übergabe."""
    def parse(s):
        return int(s.replace(".", "").replace(",", "").replace(" ", "").replace("km", "").strip())
    try:
        return parse(km_uebergabe_str) - parse(km_bewertung_str)
    except (ValueError, AttributeError):
        return 0


def km_format(km: int) -> str:
    """Formatiert KM-Wert mit Tausender-Punkt."""
    return f"{km:,}".replace(",", ".")


# ===========================================================================
# PDF-Generierung
# ===========================================================================

def generate_uebergabe_pdf(akte: dict, output_path: str = None) -> str:
    """
    Erzeugt das Übergabeprotokoll-PDF.

    Args:
        akte: Akten-Dict (mit ausgefülltem `uebergabe`-Block)
        output_path: optional, sonst aus akten_id generiert

    Returns:
        Pfad der erzeugten PDF-Datei.
    """
    u = akte["uebergabe"]
    f = akte["fahrzeug"]
    v = akte["verkaeufer"]

    # KM-Differenz berechnen
    km_diff = km_differenz(f.get("km_stand", "0"), u.get("km_stand_uebergabe", "0"))

    # Output-Pfad
    if output_path is None:
        akten_id = akte.get("akten_id") or "Akte"
        output_path = f"/mnt/user-data/outputs/{akten_id}_Uebergabe.pdf"

    # Template-Daten
    data = {
        "akten_id": akte.get("akten_id", ""),
        "uebergabe_datum": u.get("uebergabe_am") or datetime.now().strftime("%d.%m.%Y"),
        "uebergabe_durch": u.get("uebergabe_durch", ""),
        "verkaeufer": v,
        "fahrzeug": f,
        "km_bewertung": f.get("km_stand", "—"),
        "km_uebergabe": u.get("km_stand_uebergabe", "—"),
        "km_differenz": km_format(km_diff) if km_diff > 0 else "0",
        "tankstand": u.get("tankstand", "—"),
        "anzahl_schluessel": u.get("anzahl_schluessel", "—"),
        "bordmappe": u.get("bordmappe_vorhanden", False),
        "serviceheft": u.get("serviceheft_vorhanden", False),
        "kfz_schein": u.get("kfz_schein_vorhanden", False),
        "kfz_brief": u.get("kfz_brief_vorhanden", False),
        "winterreifen": u.get("winterreifen_mitgebracht", False),
        "winterreifen_zustand": u.get("winterreifen_zustand", ""),
        "neue_schaeden": u.get("neue_schaeden", "").strip(),
        "allgemeiner_zustand": u.get("allgemeiner_zustand", "i.O."),
        "bemerkungen": u.get("bemerkungen", "").strip(),
        "fotos_hinzugefuegt": u.get("fotos_hinzugefuegt", False),
    }

    # Logo-Pfad
    skill_root = Path(__file__).resolve().parent.parent
    logo_file = skill_root / "assets" / "logo.jpg"
    data["logo_path"] = f"file://{logo_file}" if logo_file.exists() else ""

    # Template rendern
    template_dir = skill_root / "templates"
    env = Environment(loader=FileSystemLoader(str(template_dir)))
    template = env.get_template("uebergabe.html")
    html_content = template.render(**data)

    # PDF schreiben
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    HTML(string=html_content, base_url=str(template_dir)).write_pdf(output_path)

    return output_path


# ===========================================================================
# CLI für Test
# ===========================================================================

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from akte import neue_akte

    akte = neue_akte()
    akte["akten_id"] = "Test_Tucson_011029"
    akte["verkaeufer"]["name"] = "Aleksander Csontos"
    akte["verkaeufer"]["strasse"] = "Hauptstraße 57"
    akte["verkaeufer"]["plz_ort"] = "79341 Kenzingen"
    akte["fahrzeug"].update({
        "hersteller": "Hyundai", "modell": "Tucson",
        "fin": "TMAJE81BGMJ011029", "kennzeichen": "EM NA2004",
        "erstzulassung": "30.04.2021", "km_stand": "60.773",
    })
    akte["uebergabe"].update({
        "uebergabe_am": "15.05.2026",
        "uebergabe_durch": "Oliver Stieber",
        "km_stand_uebergabe": "60.890",
        "tankstand": "1/2",
        "anzahl_schluessel": "2",
        "bordmappe_vorhanden": True,
        "serviceheft_vorhanden": True,
        "kfz_schein_vorhanden": True,
        "kfz_brief_vorhanden": True,
        "winterreifen_mitgebracht": False,
        "neue_schaeden": "",
        "allgemeiner_zustand": "i.O.",
    })

    pfad = generate_uebergabe_pdf(akte)
    print(f"PDF erstellt: {pfad}")
